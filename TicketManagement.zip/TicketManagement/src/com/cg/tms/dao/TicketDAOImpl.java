package com.cg.tms.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.swing.plaf.basic.BasicBorders.RadioButtonBorder;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.util.Util;

public class TicketDAOImpl implements TicketDAO{
	Util util = new Util();
	Map<String,TicketBean> ticketLog;
	Map<String,String> ticketCategory;
	List<TicketCategory> list = new ArrayList<>();

	public TicketDAOImpl() {
		ticketLog = util.getTicketLog();
		ticketCategory = util.getTicketCategoryEntries();

	}
	private static final String ALPHA_NUMERIC_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	public static String randomAlphaNumeric(int count) {
		StringBuilder builder = new StringBuilder();
		while (count-- != 0) {
			int character = (int)(Math.random()*ALPHA_NUMERIC_STRING.length());
			builder.append(ALPHA_NUMERIC_STRING.charAt(character));
		}
		return builder.toString();
	}

	@Override
	public String raiseNewTicket(TicketBean ticketBean) {
		String id = randomAlphaNumeric(4);

		ticketBean.setTicketNo(id);
		ticketBean.setTicketStatus(id);

		ticketLog.put(ticketBean.getTicketNo(), ticketBean);

		return id;
	}

	@Override
	public List<TicketCategory> listTicketCategory() {

		for (Map.Entry<String,String> category : ticketCategory.entrySet()) {
			TicketCategory cat = new TicketCategory();
			cat.setTicketCategoryId(category.getKey());
			cat.setCategoryName(category.getValue());
			list.add(cat);
		}

		return list;
	}

	public static Object getKeyFromValue(Map hm, String value) {
		for (Object o : hm.keySet()) {
			if (hm.get(o).equals(value)) {
				return o;
			}
		}
		return null;
	}

	@Override
	public String getCategoryIdDetails(String ticketCategoryName) {
		if(ticketCategory.containsValue(ticketCategoryName)) {
			//ticketCategory.get(ticketCategoryName);
			Object obj = getKeyFromValue(ticketCategory,ticketCategoryName);
			return (String)obj;
		}
		return null;
	}

}
