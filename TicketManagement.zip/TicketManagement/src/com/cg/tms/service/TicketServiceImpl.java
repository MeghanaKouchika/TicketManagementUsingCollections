package com.cg.tms.service;

import java.util.List;

import com.cg.tms.dao.TicketDAO;
import com.cg.tms.dao.TicketDAOImpl;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;

public class TicketServiceImpl implements TicketService{
	TicketDAO ticketDAO;
	
	public TicketServiceImpl() {
		ticketDAO = new TicketDAOImpl();
	}
	@Override
	public String raiseNewTicket(TicketBean ticketBean) {
		return ticketDAO.raiseNewTicket(ticketBean);
	}

	@Override
	public List<TicketCategory> listTicketCategory() {
		// TODO Auto-generated method stub
		return ticketDAO.listTicketCategory();
	}
	
	@Override
	public String getCategoryIdDetails(String ticketCategoryName) {
		
		return ticketDAO.getCategoryIdDetails(ticketCategoryName);
	}

}
