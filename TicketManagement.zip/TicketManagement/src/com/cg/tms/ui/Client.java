package com.cg.tms.ui;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.service.TicketService;
import com.cg.tms.service.TicketServiceImpl;

public class Client {
	static TicketService service;
	
	public Client() {
		service = new TicketServiceImpl();
	}
	
	private void menu() {
		System.out.println("Welcome to ITIMD HelpDesk");
		System.out.println("Select one option");
		System.out.println("1)Raise a ticket");
		System.out.println("2)Exit from the system");
		
		Scanner sc = new Scanner(System.in);
		int choice = sc.nextInt();
		
		switch(choice) {
			case 1:
				
				List<TicketCategory> list = new ArrayList();
				list = service.listTicketCategory();
				TicketCategory category = new TicketCategory();
				
				Iterator it = list.iterator();
				int i = 1;
				while(it.hasNext()) {
					category = (TicketCategory) it.next();
					System.out.println(i++ + ")" + category.getCategoryName());
				}
				
				
				
				System.out.print("Enter option: ");
				int option = sc.nextInt();
				String ticketCategoryName;
				if(option == 1) {
					ticketCategoryName = "software installation";
				}
				else if(option == 2) {
					ticketCategoryName = "mailbox creation";
				}
				else if(option == 3) {
					ticketCategoryName = "mailbox issues";
				}
				else {
					System.out.println("Enter appropriate valid priority");
					break;
				}
				
				String ticketCategoryId = service.getCategoryIdDetails(ticketCategoryName);
				
				System.out.println("Enter Description related to issue");
				String description = sc.next();
				
				System.out.println("Enter Priority:1. Low 2. Medium 3. High");
				int priorityNum = sc.nextInt();
				
				String priority;
				if(priorityNum == 1) { 
					priority = "Low";
				}
				else if(priorityNum == 2) { 
					priority = "Medium";
				}
				else if(priorityNum == 3) { 
					priority = "High";
				}
				else {
					System.out.println("Enter appropriate valid priority");
					break;
				}
				
				TicketBean ticketBean = new TicketBean();
				ticketBean.setTicketDescription(description);
				ticketBean.setTicketPriority(priority);
				ticketBean.setTicketCategoryId(ticketCategoryId);
	            
				String id = service.raiseNewTicket(ticketBean);
				System.out.println("Ticket Number " + id + " logged successfully at" + new Date());
				
				break;
			case 2:
				System.out.println("Thank you");
				System.exit(0);
				break;
			default:
				break;
		}
		
	}
	
	public static void main(String[] args) {
		Client client = new Client();
		client.menu();
	}
}
