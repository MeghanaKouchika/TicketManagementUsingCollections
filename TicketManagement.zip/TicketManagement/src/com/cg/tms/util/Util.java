package com.cg.tms.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.tms.dto.TicketBean;

public class Util {
	
	private static Map<String, TicketBean> ticketLog = new HashMap<>();
	
	private static Map<String, String> ticketCategory = new HashMap<>();
	
	public static Map<String, String> getTicketCategoryEntries(){
		ticketCategory.put("tc001", "software installation");
		ticketCategory.put("tc002", "mailbox creation");
		ticketCategory.put("tc003", "mailbox issues");
		
		return ticketCategory;
	}

	public static Map<String, TicketBean> getTicketLog() {
		return ticketLog;
	}

	public static void setTicketLog(Map<String, TicketBean> ticketLog) {
		Util.ticketLog = ticketLog;
	}
	
	

}
